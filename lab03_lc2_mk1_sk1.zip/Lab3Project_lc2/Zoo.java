
/**
 * Write a description of class Zoo here.
 *
 * @author Laura Chin
 * @version September 11, 2020
 */
public class Zoo
{
    // Instance variables
    private final int initialCapacity;
    private Animal[] members;
    private int size; // number of Animals in the array at any point

    /**
     * Constructor for objects of class Zoo
     */
    public Zoo(int c) {
        // initialize instance variables
        initialCapacity = c;
        members = new Animal[initialCapacity];
        size = 0;
    }

    /**
     * Adds a new Animal to the Zoo members.
     * Calls expandCapacity() if the Zoo members is full.
     */
    public void addAnimal(Animal a) {
        if (size == members.length) {
            expandCapacity();
        }

        members[size] = a; // adds the specified Animal to the next available spot in the array
        size++; // update number of Animals in the Zoo
    }

    /**
     * Creates an array largerArray that is twice as big as members and 
     * copies all of the values in largerArray into members.
     * Members is updated to point to largerArray.
     */
    private void expandCapacity() {
        Animal[] largerArray = new Animal[2*members.length];

        for (int i = 0; i <= members.length-1; i++) {
            largerArray[i] = members[i];
        }

        // establish the new larger array into members
        members = largerArray;
    }

    /**
     * Returns a string representation of this Zoo
     * 
     * @return a string representation of this Zoo
     */
    public String toString() {
        String result = "This Zoo contains " + size + " animals:\n";

        for (int i = 0; i < size; i++) {
            result += members[i].toString() + "\n";
        }

        return result;
    }

    /**
     * Returns the index in the array the animal was found at
     * Returns -1 if the Animal is not found
     * 
     * @param a1 Animal you want to find
     */
    public int findAnimal(Animal a1) {
        int i;
        for (i = 0; i < size; i++) {
            if (members[i].equals(a1)) {
                return i;
            } 
        }
        // System.out.println(a1.name + " was not found in this zoo."); // for testing
        return -1;
    }

    /**
     * Replaces an Animal you want to remove with the last Animal in the 
     * array (effectively removing the Animal without leaving holes in the 
     * members array
     * 
     * @param a1 Animal you want to remove
     */
    public void removeAnimal(Animal a1) {
        int a1index = findAnimal(a1);
        // int i;
        // for (i = a1index; i < size-1; i++) {
        //     members[i] = members[i+1];
        // }
        members[a1index] = members[size-1];
        size--;
    }
    
    // still need to write getHealthyAnimals(), getNumofHealthyAnimals(), getNumOfSickAnimals()

    // main method for testing
    public static void main(String[] args) {
        Zoo myZoo = new Zoo(2);
        // System.out.println(myZoo);

        Animal a1 = new Animal("snake", "Zig Zag");
        Animal a2 = new Animal("chicken", "Red Crest");
        Animal a3 = new Animal("rooster", "Mean");

        myZoo.addAnimal(a1);
        myZoo.addAnimal(a2);
        myZoo.addAnimal(a3);
        System.out.println(myZoo);
    }
}
