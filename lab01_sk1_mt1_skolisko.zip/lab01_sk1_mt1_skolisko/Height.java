
/**
 * Write a description of class Height here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;


public class Height
{
    public static void main(String[] args) {
        //
        Scanner scan = new Scanner(System.in);
        
        // ask user for their height in inches
        System.out.print("What is your height in inches? ");
        double height = scan.nextDouble();
        
        // convert their height to feet and inches
        int feet = (int) height / 12;
        height -= feet * 12;
        double inches = height;
        
        // print out the results
        System.out.println("You are " + feet + " feet and " + inches + " inches.");
    }
}
