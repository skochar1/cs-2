
/**
 * Write a description of class Evictions here. All my code got deleted!
 * 
 */
import java.util.Scanner;

public class Evictions
{
    private String fileIn;
    private Town[] towns;
    final private double THRESHOLD = 0.3;
    private int maxNumTowns= 100;
    private int numTowns;
    public Evictions(String fileN){
        fileIn= fileN;
        towns = new Town[maxNumTowns];
        
    }
    
    public void readData(){
        Scanner scan = new Scanner(new File(fileIn));
        String h = scan.nextLine();
        System.out.println(h);
        while(scan.hasNext()){
            String name = scan.next();
            String state = scan.next();
            int pop = Integer.parseInt(scan.next());
            double povRate = Double.parseDouble(scan.next());
            int evictions = Integer.parseInt(scan.next());
            Town t = new Town(name,state,pop, povRate,evictions);
            towns[numTowns]=t;
            numTowns++;
        }
    }
    
    public void flagTowns(){
        for (int i = 0;i<numTowns;i++){
            
        setFlag(double THRESHOLD)
    }
    }
}
