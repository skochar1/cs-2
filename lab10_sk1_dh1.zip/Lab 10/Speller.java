
/**
 * Write a description of class Speller here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
//should check a document and save misspelled words in a container and print them
public class Speller
{
    private String fileName;
    private EnglishHashDictionary object;
    private LinkedList misSpelled;
    /**
     * Constructor for objects of class Speller
     */
    public Speller(String name)
    {
      object = new EnglishHashDictionary(name);
    }
    
    public void checkSpell(String doc){
        
    }
    
    public String toString(){
        String s = "--------------------------------------------------\n";
        s+= "This program is spell checking file "+fileName+" using dictionary "+
        EnglishHashDictionary.fileName + ". It contains "+ misSpelled.size()+
        " misspelled words and they are: \n";
        
        return s;
    }
    
    public static void main(String[] args){
        
    }
}
