import java.util.*;
/**
 * Write a description of class Task0 here.
 *
 * @author Danika Heaney
 * @version October 1, 2020
 */
public class Task0
{
     
public static void main(String[] args){
 Hashtable<String, String> dates = new Hashtable<String, String>(10); // 10 initial spots
 // populate the table
 dates.put("Commencement", "6/01/2018");
 dates.put("Last Day of Classes", "5/11/2018");
 dates.put("Marathon Monday", "4/16/2018");
 System.out.println(dates); // print in order they were added (I though it was random tho?!?)
 String str = dates.get("Commencement");
 System.out.println(str); //prints the date "6/01/2018"
 System.out.println((dates.containsKey("Last Day of Classes"))); //prints true
 System.out.println((dates.containsKey("Sam's birthday"))); //prints false
 for (int i=0; i<=20; i++ ) {
   dates.put("Important Day"+i, "4/"+ i +"/2018");
}
System.out.println(dates); //hash table is big enough to hold all values
}
}
