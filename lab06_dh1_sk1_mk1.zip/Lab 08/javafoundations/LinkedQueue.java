package javafoundations;

import javafoundations.exceptions.*;

/*
 * A linked implementation of the Queue Interface.
 * */
public class LinkedQueue<T> implements Queue<T>
{
    private int count;
    private LinearNode<T> front, rear;

    /**
     * Constructor
     * Creates an empty queue.
     */
    public LinkedQueue()
    {
        count = 0;
        front = rear = null;
    }

    /**
     * Adds the specified element to the rear of the queue.
     *
     * @param The element to be enqueued into the queue
     */
    public void enqueue (T element)
    {
        LinearNode<T> node = new LinearNode<T>(element);

        if (count == 0)
            front = node;
        else
            rear.setNext(node);

        rear = node;
        count++;
    }

    public T dequeue() throws EmptyCollectionException
    {
        if (count ==0) {
            throw new EmptyCollectionException("Dequeue failed. Queue is empty.");
        }
        T temp = front.getElement();
        front = front.getNext();
        count--;
        return temp;
    }

    /**
     * 
     */
    public int size()
    {
        return count;
    }

    public String toString()
    {
        String s = "";
        LinearNode<T> current = front;
        for (int i=0; i<count;i++)
        {
            s = s +"\t"+ current.getElement();
            current = current.getNext();
        }
        return s;
    }

    public boolean isEmpty()
    {
        return count == 0;
    }

    public T first() throws EmptyCollectionException
    {
        if (count ==0) {
            throw new EmptyCollectionException("first failed. Queue is empty.");
        }
        return front.getElement();
    }

   
}
