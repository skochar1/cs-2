/* Intro.java
 * Asks the user for information and prints out values
 * Key concepts: Scanner class for input, + for String concatenation, declaring
 *   variables of different types, converting numbers to Strings for printing
 * CS230 Lab 1 
 * Written by: CS230
 * Modified by:
 * Modified date:jan2715 
 */
import java.util.Scanner;

public class Intro {
  public static void main (String[] args) {
    // variables declared and initialized
    Scanner scan = new Scanner(System.in);
    System.out.print("What is your name? ");
    String yourName = scan.nextLine();
    System.out.print("What is your graduation year? ");
    String year = scan.nextLine();
    System.out.print("How much money do you have in your pocket? ");
    double money = scan.nextDouble();
    System.out.print("Are you a CS major? ");
    boolean csMajor = scan.nextBoolean();
    
    // Print the output to the console
    System.out.println(); //blank line 
    System.out.println("Hi, my name is " + yourName);
    System.out.println("I am in the class of "+ year); // year works solo too
    System.out.println("I have $" + money + " in my pocket.");
    System.out.println(" and I am a CS major: " + csMajor);
    System.out.println(); 
  } // closes main 
  
}// closes Intro class

