import java.util.*;
import java.io.*;
/**
 * Write a description of class EnglishHashDictionary here.
 *
 * @author Danika Heaney
 * @version October 1, 2020
 */
public class EnglishHashDictionary implements Dictionary
{
    private Hashtable<String,String> dictionary;
    public String fileName;

    /**
     * Constructor for objects of class EnglishHashDictionary
     */
    public EnglishHashDictionary(String name)
    {
        dictionary = new Hashtable<String,String>();
        fileName = name;
        fillDictionary(name);
    }

    /**
     * Adds input String to the dictionary 
     */
    public void addWord(String word){
        dictionary.put(word,word);
    } 

    /**
     * Adds input String to the dictionary 
     */
    private void fillDictionary(String name) {
        try{
            File file = new File(name);
            Scanner scan = new Scanner(file);
            while (scan.hasNext()){
                String word = scan.nextLine();
                addWord(word);
            }
        }
        catch(FileNotFoundException e){
            System.out.println("Failed to read from "+name);
        }
    } 

    /**
     * Searches the dictionary for the input String.
     * Returns true if found, false otherwise.
     */
    public boolean searchWord(String word){
        return dictionary.containsKey(word);
    }

    /**
     * Removes from the dictionary for the input String.
     * It does nothing if the input word is not in the dictionary.
     */
    public void removeWord(String word){
        dictionary.remove(word);
    }

    public static void main(String[] args){
        EnglishHashDictionary hash1 = new EnglishHashDictionary("EnglishWords.txt");
        System.out.println(hash1.searchWord("horse"));

    }
}
