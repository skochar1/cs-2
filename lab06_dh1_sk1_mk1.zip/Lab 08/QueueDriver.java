import javafoundations.LinkedQueue;
/**
 * Write a description of class QueueDriver here.
 *
 * @author Danika, Manasvi, Shreya
 * @version Sept. 25, 2020
 */
public class QueueDriver
{
    public static void main(String[] args)
    {
       LinkedQueue<String> queue1 =new LinkedQueue<String>();
       queue1.enqueue("Hello");
       queue1.enqueue("Goodbye");
       queue1.enqueue("Happy Birthday!!");
       queue1.enqueue("Manasvi :)");
       System.out.println(queue1);
       
    }
}
