import java.util.Scanner;  // for reading from keyboard
import javafoundations.*; // for the LinkedBinaryTree and all

public class AnimalExpert {
  
  private LinkedBinaryTree<String> theTree;
  
  // sets up 'expert' database
  public AnimalExpert(){
    String e1 = "Is the animal big?";
    String e2 = "Does it live in a cage?";
    String e3 = "Does it eat grass?";
    String e4 = "Does it meow?";
    String e5 = "Does it chirp?";
    //String e6 = "Does it have a long neck?";
    String e6 = "Does it like water?";
    String e7 = "Does it moo?";
    String e8 = "It's a dog!";
    String e9 = "It's a cat!";
    String e10 = "It's a hamster!";
    String e11 = "It's a bird!";
    String e12 = "It's a lion!";
    String e13 = "It's a crocodile!";
    String e14 = "It's a horse!";
    String e15 = "It's a cow!";
    
    //create the LinkedBinarTree

  }

  //define any other methods
  
  //add a main()

} // AnimalExpert class

