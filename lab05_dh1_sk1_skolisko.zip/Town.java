
/**
 * Keeps information about a town and its eviction data, in a certain year.
 *
 * @author cs230 staff (SK)
 * @version Oct 7, 2019
 */
public class Town implements Comparable<Town>
{
    private String name;         // name of this town
    private String state;        // state it belong to
    private int population;
    private double povertyRate;  //from 0.0 to 100.00 %
    private int evictions;       //number of evictions that actually happened
    private double evictionRate; //defined as % of evictions over
    //the town population, like 2.26 for 2.26%
    private boolean flagged; //true when evictionRate > threshold

    final private double SMALL_NUM = 0.0001; //to be used when testing doubles for equality

    /**
     * constructs a Town object given its name, state, population, poverty rate,
     *                                     and num of actual evictions in a certain year.
     *
     * @param name the name of the Town
     * @param state the state this town belong to
     * @param pop the population of the town
     * @param povRate the poverty rate in the town
     * @param evictions the number of actual evictions in this town in a certain year
     *
     * */
    public Town(String name, String state, int pop, double povRate,
    int evictions)
    {
        this.name = name;
        this.state = state;
        population = pop;
        povertyRate = povRate;
        this.evictions = evictions;
        flagged = false; //default value

        //calculate and assigne the evictionRate
        evictionRate = ((double)evictions/population) * 100; //ex: 2.26 for 2.26%
        //pay attention here as you devide two integers, expecting a non-zero double value
    }

    /**
     * returns the eviction rate for this town
     *
     * @return The evictionRate for this town
     * */
    public double getEvictionRate(){
        return evictionRate;
    }

    /**
     *  getter to return whether this town is on watch or not
     *
     * @return true if this town should be on watch, false otherwise
     * */
    public boolean getFlagged() {
        return flagged;
    }

    /**
     *  getter to return the name of this town
     *
     * @return the name of this town
     * */
    public String getName() {
        return name;
    }

    /**
     *  getter to return the satte of this town
     *
     * @return the state of this town
     * */
    public String getState() {
        return state;
    }

    /*
     * Determines whether the current Town is volnerable, based on the input threshold,
     * and flags it accordingly
     *
     * @param the threshold used to determine whether this Town is volnerable
     * */
    public void setFlag(double threshold) {
        //true if town's eviction rate is greater than the threshold, false otherwise
        this.flagged = this.evictionRate > threshold;
    }



    public static void main(String[] args) {
        //create two town for testing
        Town holland = new Town("Holland", "TX", 609, 12.16, 4);
        Town sanCarlos = new Town("SanCarlos", "CA", 29454, 1.52, 4);
    }

}
