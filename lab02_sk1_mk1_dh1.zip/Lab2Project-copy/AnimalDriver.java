import java.util.Scanner;

/**
 * AnimalDriver tests the class Animal.
 *
 * @author Danika Heaney
 * @collaborators Manasvi and Shreya
 * @version Sept. 8, 2020
 */
public class AnimalDriver
{
    public static void main(String[] args)
    {
        
        Animal horse1 = new Animal("horse","Sunny","nahhh",false,4);
        Animal fish1 = new Animal("fish","Blueberry","glub",false,0);
        Animal dog1 = new Animal("dog", "Dona");
        //testing the toString() method
        System.out.println("testing the toString() method");
        System.out.println(horse1.toString());
        System.out.println(fish1.toString());
        System.out.println(dog1);
        //testing the getter methods
        System.out.println("testing the getter method");
        System.out.println(horse1.getName());
        System.out.println(fish1.getNumberLegs());
        System.out.println(dog1.getCanFly());
        //testing setter methods
        System.out.println("testing the setter method (expected: horsie"+
            ", 2, true)");
        horse1.setType("horsie");
        System.out.println(horse1.getType());
        fish1.setNumLegs(2);
        System.out.println(fish1.getNumberLegs());
        dog1.setCanFly(true);
        System.out.println(dog1.getCanFly());
        //testing other methods
        System.out.println("testing other methods");
        horse1.tookFlyingLessons();
        System.out.println("expected: true " + "got: "+horse1.getCanFly());
        fish1.likesToImitateCats();
        System.out.println("expected: meow " + "got: "+fish1.getVoice());
        dog1.speak();
        System.out.println(horse1.converse(dog1));
        //testing for readAndCreateAnimal()
        Animal a1 = Animal.readAndCreateAnimal();
        
        

    }
}
