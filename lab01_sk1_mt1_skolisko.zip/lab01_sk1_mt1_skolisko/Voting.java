;
/**
 * Write a description of class Voting here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

import java.util.Scanner;

public class Voting
{
   public static void main(String[] args) {
   Scanner scan = new Scanner(System.in);
   System.out.print("What year were you born in? ");
   int birthYear = scan.nextInt();
   int yearDiff = 2020 - birthYear;
   
   if (yearDiff > 18) {
       System.out.println("You are eligible to vote.");
    }
   else if (yearDiff == 18) {
       System.out.print("What is your birth month number? ");
       int birthMonth = scan.nextInt();
       
       if (birthMonth < 11) {
           System.out.println("You are eligible to vote.");
        }
       else {
           System.out.println("You are too young to vote.");
        }
    }
   else {
       System.out.println("You are too young to vote.");
    }
   }
}
