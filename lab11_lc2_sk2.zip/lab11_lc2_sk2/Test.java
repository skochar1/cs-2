// Testing iterators using BTNode
// Sohie CS230 Lab 11

import javafoundations.*;

public class Test {
  public static void main(String [] args) {
    BTNode<String> s1 = new BTNode<String>("meckila");
    BTNode<String> s2 = new BTNode<String>("meryl");
    BTNode<String> s3 = new BTNode<String>("julia");  
    BTNode<String> s4 = new BTNode<String>("rachel");
    BTNode<String> s5 = new BTNode<String>("amal"); 
    BTNode<String> s6 = new BTNode<String>("sharon");
    BTNode<String> s7 = new BTNode<String>("farren"); 
    BTNode<String> s8 = new BTNode<String>("sian");
    BTNode<String> s9 = new BTNode<String>("kim");
    BTNode<String> s10 = new BTNode<String>("cece");
    BTNode<String> s11 = new BTNode<String>("wendy");
    BTNode<String> s12 = new BTNode<String>("emily");
    BTNode<String> s13 = new BTNode<String>("stephanie");
    BTNode<String> s14 = new BTNode<String>("aline");
    BTNode<String> s15 = new BTNode<String>("jennifer");
    BTNode<String> s16 = new BTNode<String>("sheree");
    BTNode<String> s17 = new BTNode<String>("michelle");
    BTNode<String> s18 = new BTNode<String>("sam");
    
   
    
  }
  
}
