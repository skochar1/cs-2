import java.util.Scanner;
/**
 * Write a description of class Animal here.
 *
 * @author Danika Heaney
 * @collaborators Manasvi and Shreya
 * @version Sep. 6 2020
 */
public class Animal
{
    // instance variables 
    private String type, name, voice;
    private boolean canFly;
    private int number_legs;
    private static int numAnimal = 0;
    private int animalID;


    /**
     * Constructor for objects of class Animal
     * @param type
     * @param name
     * @param voice
     * @param canFly
     * @param number_leg 
     */
    public Animal(String ty, String na, String vo, boolean fl,int num)
    {
        // initialise instance variables
        type = ty;
        name = na;
        voice = vo;
        canFly = fl;
        number_legs = num;
        numAnimal++;
        animalID = numAnimal;
    }
    public Animal(String ty, String na)
    {
        type = ty;
        name = na;
        voice = "hi";
        canFly = false;
        number_legs = 3;
        numAnimal++;
        animalID = numAnimal;
    }
    /**
     * This method creates a String of the animals characteristics.
     * @return String of Animal
     */
    public String toString()
    {
        String flyOrNot = (this.canFly) ? "can":"cannot";
        String finalStatment = (this.name+" is a "+this.type+" with "+
                this.number_legs+" legs that "+flyOrNot+" fly who says "+this.voice+". ID: "+this.animalID);
        return finalStatment;
    }

    public String getType()
    {
        return this.type;
    }

    public String getName()
    {
        return this.name;
    }

    public String getVoice()
    {
        return this.voice;
    }

    public boolean getCanFly()
    {
        return this.canFly;
    }

    public int getNumberLegs()
    {
        return this.number_legs;
    }

    public void setType(String type1)
    {
        this.type = type1;
    }

    public void setName(String name1)
    {
        this.name = name1;
    }

    public void setVoice(String voice1)
    {
        voice = voice1;
    }

    public void setCanFly(boolean canFly)
    {
        this.canFly = canFly;
    }

    public void setNumLegs(int l)
    {
        number_legs = l;
    }

    public void tookFlyingLessons()
    {
        canFly = true;
    }

    public void coughtLaryngitis()
    {
        voice = "";
    }

    public void likesToImitateCats()
    {
        voice = "meow";
    }

    public void speak()
    {
        System.out.println(this.voice+" "+this.voice+" "+this.voice);
    }

    /**
     * 
     * @param Animal from the class.
     * @return Sting of two animals having a conversation.
     */
    public String converse(Animal a2)
    {
        String intro = "A conversation between "+this.name+" and "+a2.getName()+":\n";
        String a1 = this.voice;
        return (intro+a1+" "+a2.getVoice()+" "+a1+" "+a2.getVoice()+" "+a1+" "+a2.getVoice());
    }

    public static Animal readAndCreateAnimal()
    {
        Scanner scan = new Scanner(System.in);
        System.out.println("What is the name of the animal? ");
        String name = scan.nextLine();
        System.out.println("What is the type of animal? ");
        String type = scan.nextLine();
        System.out.println("What sound does the animal make? ");
        String voice = scan.nextLine();
        System.out.println("Can the animal fly?(true/false) ");
        boolean canFly = scan.nextBoolean();
        System.out.println("How many legs does the animal have? ");
        int number_legs = scan.nextInt();
        scan.nextLine();
        return new Animal(name, type, voice, canFly, number_legs);
        
        
    }
    public static void main(String[] args)
    {
        Animal a1 = readAndCreateAnimal();
    }
}
