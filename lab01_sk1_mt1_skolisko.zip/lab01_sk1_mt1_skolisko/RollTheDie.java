
/**
 * Write a description of class RollTheDie here.
 *
 * @Shreya (driving my own version of the file)
 * @version (a version number or a date)
 */
import java.util.Random;

public class RollTheDie
{
    public static int rollDie() {
        // intialize random object from random class
        Random rand = new Random();
        
        // store random int
        int rolled = rand.nextInt(6) + 1;
        return rolled;
    }
    
    public static void main(String[] args) {
        int value1 = rollDie();
        int value2 = rollDie();
        System.out.println("You rolled a " + value1 + " and a " + value2);
    }
}
