
/**
 * Write a description of class Intro2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Intro2
{
    

     public static void main(String [] args) {
     //replace the values of the following variables as you wish
        String name = "Shreya";
        int gradYear = 2023;
        double money = 12.53;
        boolean csMajor = true;

        System.out.println("Hello there! My name is " + name + ".");
        System.out.println("I am Wellesley class of " + gradYear + ".");
        System.out.println("I am a computer science major: " + csMajor);
        System.out.println("And, I'll buy you coffee! I have $" +
            money + " on me.");
        double x = 36.41;
        double y = x*100;
        System.out.println(y);
        
        int z1 = (int)(y);
        System.out.println("z1: " + z1);
        
        long z2 = Math.round(y);
        System.out.println("z2: " + z2);
    }

    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class Intro2
     */
    public Intro2()
    {
        // initialise instance variables
        x = 0;
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public int sampleMethod(int y)
    {
        // put your code here
        return x + y;
    }
}
