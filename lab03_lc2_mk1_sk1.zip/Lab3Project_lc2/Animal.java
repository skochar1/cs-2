/** Animal.java
 * CS230 
 * Lab 2 and 3 
 * Writing classes from scratch
 * by Sohie and Stella
 * */

import java.util.Scanner;

public class Animal {
    //static variables
    private static int numOfAnimals = 0;

    // instance variables
    private String type; 
    public String name;
    private String voice;
    private boolean canFly;
    private int numberLegs;
    private boolean goodHealth;

    /*
     * constructor for the Animal class
     * 
     * @param t the type of the animal
     * @param n the name of the animal
     * @param v the voice of the animal
     * @param fly whether the animal can or cannot fly
     * @param numLegs the number of legs of the animal
     * @param health the status of the health of the animal
     */
    public Animal(String t, String n, String v, 
    boolean fly, int numlegs, boolean health) {
        this.type = t;
        this.name = n;
        this.voice = v;
        this.canFly = fly;
        this. numberLegs = numlegs;
        goodHealth = health;

        numOfAnimals++;
    }

    /*
     * second constructor for the Animal class, with 
     * some default values: silent voice, cannot fly, 4 legs,
     * and good health
     * 
     * @param t the type of the animal
     * @param n the name of the animal
     * 
     */
    public Animal(String t, String n) {
        this.type = t;
        this.name = n;
        this.voice = "";
        this.canFly = false;
        this. numberLegs = 4;
        this.goodHealth = true;

        numOfAnimals++;
    }

    /**
     * sets instance variable canFly to be true
     * 
     */
    public void tookFlyingLessons() {
        canFly = true;
    }

    /**
     * sets instance variable voice to be the empty string
     * 
     */
    public void caughtLaryngitis() {
        voice = "";
    }

    /**
     * sets instance variable voice to be "meow"
     * 
     */
    public void likesToImitateCats() {
        voice = "meow";
    }

    /**
     * sets instance variable goodHealth to the input status
     * 
     * @param status a boolean to indicate the new 
     * health status of this animal
     */
    public void setHealth(boolean status) {
        goodHealth = status;
    }

    /**
     * returns the voice of this animal
     * 
     * @return The voice of this animal
     */
    public String getVoice() {
        return voice;
    }

    /**
     * returns the tyoe of this animal
     * 
     * @return The tye of this animal
     */
    public String getType() {
        return type;
    }

    /**
     * returns the name of this animal
     * 
     * @return The name of this animal
     */
    public String getName() {
        return name;
    }

    /**
     * returns a boolean, indicating whether this animal can fly
     * 
     * @return true if this animal can fly, false otherwise
     */
    public boolean getCanFly() {
        return canFly;
    }

    /**
     * returns the number of legs of this animal
     * 
     * @return the number of legs of this animal
     */
    public int getNumberLegs() {
        return numberLegs;
    }

    /**
     * returns the status of the health of this animal
     * 
     * @return true if this animal had good health, false otherwise
     */
    public boolean isHealthGood() {
        return goodHealth;
    }

    /**
     * sets the voice of this animal to the input value
     * 
     * @param the new voice of this animal
     */
    public void setVoice(String v) {
        voice = v;
    }

    /**
     * sets the name of this animal to the input value
     * 
     * @param the new name of this animal
     */
    public void setName(String n) {
        name = n;
    }

    /**
     * sets the type of this animal to the input value
     * 
     * @param the new type of this animal
     */
    public void setType(String t) {
        type = t;
    }

    /**
     * sets the fly property of this animal to the input value
     * 
     * @param the new fly property of this animal
     */
    public void setCanFly(boolean fly){
        canFly = fly;
    }

    /**
     * prints the voice of this animal 3 times
     * 
     */
    // Prints the value of the instance variable voice 3x
    public void speak() {
        System.out.println(voice + " " + voice + " " + voice);
    }

    /**
     * sets the number of legs of this animal to the input value
     * 
     * @param the new number of legs of this animal
     */
    public void setNumberLegs(int legs){
        numberLegs = legs;
    }

    /**
     * returns a string representation of this animal
     * 
     * @return a string representation of this animal
     */
    public String toString() {
        String s = "";
        String doesItFly = canFly ? "" : "not";
        String isItHealth = "";
        if (!goodHealth) {
            isItHealth = " not ";
        }

        s+= name + " is a " + type + " with " +numberLegs + 
        " legs" +  " that can" + doesItFly + " fly" + 
        " that says "+ voice + ". This animal is " + isItHealth +
        " in good health"; 

        return s;
    }

    // Returns a string representation of conversation between two animals.
    // One animal is the the invoker of this method, and the 
    // other is passed as a parameter (other), 
    //and the other animal is 

    /**
     * returns a conversation between this animal 
     * and the input one
     * 
     * @param the animal this one converses with
     */
    public String conversation(Animal other) {
        String header = "A conversation between " + this.name + " and " + other.name + ":" + "\n";
        String space = " ";
        String convo = space + this.getVoice() + "\n";

        convo += space + other.getVoice() + "\n";
        convo += space + this.getVoice()+ "\n";
        convo += space + other.getVoice() + "\n";

        return header +  convo;
    }

    /**
     * Returns true if this animal and the input one have 
     * the same type and the same name, false othrwise
     * 
     * @param The animal to be compared to this one
     * @return true if the two animals are the same, false otherwise
     */

    public boolean equals(Animal other) {
        return (this.type).equals(other.type) && (this.name).equals(other.name);
    }

    /*
     * Uses a scanner to read information about an animal from the user.
     * Then it creates the animal, and at the end returns it.
     * 
     * @return The animal that was created based on the user's input
     * */
    public static Animal readAndCreateAnimal() {
        Scanner s = new Scanner(System.in);

        //ask for and read input from the user
        System.out.println("What kind of animal is this?");
        String kind = s.nextLine();

        System.out.println("What is the name of it?");
        String name = s.nextLine();

        System.out.println("What sound does it make?");
        String sound = s.nextLine();

        System.out.println("Can it fly (true/false)?");
        boolean fly = s.nextBoolean();

        System.out.println("How many legs does it have?");
        int legs = s.nextInt();

        boolean h = true;
        System.out.println("Is this animal in good health (y/n)?");
        String str = s.next();
        if (str.equalsIgnoreCase("n")) {
            h = false;
        }

        s.close();
        // Create the animal and return it
        return new Animal(kind, name, sound, fly, legs, h);
    }
    
    // main() method for testing
    // This is the method that is automatically executed when the Animal 
    //class is run
    public static void main (String [] args ) {
        System.out.println("--------------Starting Round 1--------------");

        Animal a1 = readAndCreateAnimal();
        System.out.println(a1);

        System.out.println("So far, " + Animal.numOfAnimals + " animals have been created.\n");

        Animal pet1 = new Animal("spider","charlotte", " ",false,8, true);
        Animal pet2 =  new Animal("dog","lassie");
        Animal pet3 = new Animal("frog","bill","ribbit",false,4, false);
        System.out.println(pet1);
        System.out.println(pet2);
        System.out.println(pet3);

        System.out.println("So far, " + Animal.numOfAnimals + " animals have been created.\n");

        /* System.out.println("animal's name: " + a1.getName());
        System.out.println("animal's voice: " + a1.getVoice());
        System.out.println("can the animal fly: " + a1.getCanFly());
        System.out.println("number of legs the animal has: " + 
        a1.getNumberLegs());

        System.out.println(pet3);
        System.out.println(pet3.getType());
        pet3.setType("prince");
        System.out.println(pet3.getType());
        pet3.setNumberLegs(2);
        System.out.println(pet3);
        System.out.println("--------------Ending Round 1--------------");

        System.out.println("--------------Starting Round 2--------------");
        Animal a2 = new Animal("cow","helga","moooo",false,4);
        System.out.println(a1.conversation(a2));

        a1.setVoice("everyone dance!");
        System.out.println(a1.conversation(a2));
        System.out.println("--------------Ending Round 2--------------");

        Animal a3 = new Animal("dog","lassie");
        System.out.println(a3);

        Animal a4 = new Animal("flamingo","pinky");
        System.out.println(a4);

        a1.speak();

        System.out.println(pet1);
        pet1.speak();

        System.out.println(pet2);
        pet2.speak();

        System.out.println(pet3);
        pet3.speak();
        pet3.likesToImitateCats();
        pet3.speak();
        pet3.tookFlyingLessons();
        System.out.println(pet3);

        //this is an interesting way of creating a worm!
        Animal inch = new Animal("worm","Pete");
        System.out.println(inch);
        inch.setNumberLegs(0);
        System.out.println(inch);

        inch.speak();
        inch.setVoice("everybody dance!");
        inch.speak();

        System.out.println(inch.conversation(pet3));
         */
    }
}
